/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  milandeket
 * Created: Nov 29, 2016
 */

truncate table user;
insert into user (name, email) values ('David Williams', 'dwilliams0@dropbox.com');
insert into user (name, email) values ('Roy Reynolds', 'rreynolds1@devhub.com');
insert into user (name, email) values ('Thomas Pierce', 'tpierce2@networksolutions.com');
insert into user (name, email) values ('Louise Stephens', 'lstephens3@dropbox.com');
insert into user (name, email) values ('Jean Kim', 'jkim4@macromedia.com');
insert into user (name, email) values ('Barbara Robertson', 'brobertson5@ftc.gov');
insert into user (name, email) values ('Peter Olson', 'polson6@baidu.com');
insert into user (name, email) values ('Louis Howell', 'lhowell7@oracle.com');
insert into user (name, email) values ('Dennis Simpson', 'dsimpson8@umich.edu');
insert into user (name, email) values ('Daniel Nguyen', 'dnguyen9@wordpress.com');
insert into user (name, email) values ('Aaron Gardner', 'agardnera@google.com.hk');
insert into user (name, email) values ('Wanda Freeman', 'wfreemanb@wikipedia.org');
insert into user (name, email) values ('Kevin Carroll', 'kcarrollc@biglobe.ne.jp');
insert into user (name, email) values ('Timothy Martinez', 'tmartinezd@imgur.com');
insert into user (name, email) values ('Walter Wells', 'wwellse@about.me');
insert into user (name, email) values ('Carlos Hall', 'challf@cnbc.com');
insert into user (name, email) values ('Howard Fernandez', 'hfernandezg@vistaprint.com');
insert into user (name, email) values ('Jennifer Sullivan', 'jsullivanh@apache.org');
insert into user (name, email) values ('Carlos Ryan', 'cryani@cbsnews.com');
insert into user (name, email) values ('Sean Mitchell', 'smitchellj@multiply.com');
insert into user (name, email) values ('Antonio Evans', 'aevansk@va.gov');
insert into user (name, email) values ('Matthew Spencer', 'mspencerl@moonfruit.com');
insert into user (name, email) values ('Walter Cox', 'wcoxm@wsj.com');
insert into user (name, email) values ('Jimmy Walker', 'jwalkern@theatlantic.com');
insert into user (name, email) values ('Billy Carroll', 'bcarrollo@ihg.com');
insert into user (name, email) values ('Linda Rodriguez', 'lrodriguezp@etsy.com');
insert into user (name, email) values ('Eugene Gilbert', 'egilbertq@mail.ru');
insert into user (name, email) values ('Linda Wright', 'lwrightr@kickstarter.com');
insert into user (name, email) values ('Judy Perry', 'jperrys@amazon.co.jp');
insert into user (name, email) values ('Harry Gutierrez', 'hgutierrezt@unicef.org');
insert into user (name, email) values ('Jason Freeman', 'jfreemanu@unicef.org');
insert into user (name, email) values ('Christine Moreno', 'cmorenov@devhub.com');
insert into user (name, email) values ('Eugene Welch', 'ewelchw@networksolutions.com');
insert into user (name, email) values ('Frank Bryant', 'fbryantx@sun.com');
insert into user (name, email) values ('Albert George', 'ageorgey@discuz.net');
insert into user (name, email) values ('Jacqueline Ryan', 'jryanz@imageshack.us');
insert into user (name, email) values ('Katherine Perry', 'kperry10@auda.org.au');
insert into user (name, email) values ('Jane Freeman', 'jfreeman11@loc.gov');
insert into user (name, email) values ('Jerry Stewart', 'jstewart12@qq.com');
insert into user (name, email) values ('Ralph Gilbert', 'rgilbert13@illinois.edu');
insert into user (name, email) values ('Jennifer Young', 'jyoung14@w3.org');
insert into user (name, email) values ('Fred Boyd', 'fboyd15@cloudflare.com');
insert into user (name, email) values ('Jack Duncan', 'jduncan16@twitter.com');
insert into user (name, email) values ('Craig Spencer', 'cspencer17@networksolutions.com');
insert into user (name, email) values ('Randy Riley', 'rriley18@over-blog.com');
insert into user (name, email) values ('Amanda Henry', 'ahenry19@imdb.com');
insert into user (name, email) values ('Donald Morrison', 'dmorrison1a@zdnet.com');
insert into user (name, email) values ('Wanda Hamilton', 'whamilton1b@aol.com');
insert into user (name, email) values ('Robert Fox', 'rfox1c@slashdot.org');
insert into user (name, email) values ('Helen Little', 'hlittle1d@google.cn');
